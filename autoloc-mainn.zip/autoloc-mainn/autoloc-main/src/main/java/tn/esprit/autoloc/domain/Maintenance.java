package tn.esprit.autoloc.domain;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Maintenance {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    long idMaintenance;

    LocalDate dateDebut;
    LocalDate dateFin;
    String description;
    @ManyToOne
    @JoinColumn(name = "vehicule_id")
    private Vehicule vehicule;

    public void setId(Long id) {
    }
}
